# ProdigyInfotech_DS_Task1
This is Task 1 of Data Science Internship at Prodigy Infotech.
